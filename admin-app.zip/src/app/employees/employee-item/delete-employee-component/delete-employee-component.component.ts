import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-employee-component',
  templateUrl: './delete-employee-component.component.html',
  styleUrls: ['./delete-employee-component.component.css']
})
export class DeleteEmployeeComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
