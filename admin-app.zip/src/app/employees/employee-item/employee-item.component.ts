import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DeleteEmployeeComponentComponent } from './delete-employee-component/delete-employee-component.component';

@Component({
  selector: 'app-employee-item',
  templateUrl: './employee-item.component.html',
  styleUrls: ['./employee-item.component.css']
})
export class EmployeeItemComponent implements OnInit {

  openEditEmployee: boolean = false;

  constructor(private dialog: MatDialog) { }

  ngOnInit(): void {
  }

  onEditEmployee(){
    this.openEditEmployee = true;
  }
  onClosed(){
    this.openEditEmployee = false;
  }

  onDelete(){
    this.dialog.open(DeleteEmployeeComponentComponent)
  }
}
