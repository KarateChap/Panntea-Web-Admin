import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-monitoring-item',
  templateUrl: './monitoring-item.component.html',
  styleUrls: ['./monitoring-item.component.css']
})
export class MonitoringItemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
