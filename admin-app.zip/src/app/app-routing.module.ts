import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AnalyticsComponent } from './analytics/analytics.component';
import { CustomersComponent } from './customers/customers.component';
import { EmployeesComponent } from './employees/employees.component';
import { FeedsComponent } from './feeds/feeds.component';
import { LoginComponent } from './login/login.component';
import { MainNavComponent } from './main-nav/main-nav.component';
import { MonitoringComponent } from './monitoring/monitoring.component';
import { ForPickUpComponent } from './notifications/for-pick-up/for-pick-up.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { OrderReceivedComponent } from './notifications/order-received/order-received.component';
import { PendingOrdersComponent } from './notifications/pending-orders/pending-orders.component';
import { PreparingComponent } from './notifications/preparing/preparing.component';
import { ProductsComponent } from './products/products.component';
import { WelcomePageComponent } from './welcome-page/welcome-page.component';

const routes: Routes = [
  {path: '', redirectTo: '/welcome-page', pathMatch: 'full'},
  {path: 'welcome-page', component: WelcomePageComponent},
  {path: 'login-page', component: LoginComponent},
  {path: 'main-nav', component: MainNavComponent, children: [
    {path: 'analytics', component: AnalyticsComponent},
    {path: 'products', component: ProductsComponent},
    {path: 'notifications', component: NotificationsComponent, children:[
      {path: 'pending-orders', component: PendingOrdersComponent},
      {path: 'preparing', component: PreparingComponent},
      {path: 'for-pick-up', component: ForPickUpComponent},
      {path: 'order-received', component: OrderReceivedComponent}
    ]},
    {path: 'monitoring', component: MonitoringComponent},
    {path: 'employees', component: EmployeesComponent},
    {path: 'feeds', component: FeedsComponent},
    {path: 'customers', component: CustomersComponent}
  ]},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
