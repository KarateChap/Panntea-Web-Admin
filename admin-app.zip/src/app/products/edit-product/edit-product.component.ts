import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent implements OnInit {
  @Output() close = new EventEmitter<void>();

  constructor(
  ) { }

  ngOnInit(): void {
  }

  onClose(){
    this.close.emit();
  }
}
