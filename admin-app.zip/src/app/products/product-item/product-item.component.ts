import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DeleteProductComponent } from './delete-product/delete-product.component';

@Component({
  selector: 'app-product-item',
  templateUrl: './product-item.component.html',
  styleUrls: ['./product-item.component.css']
})
export class ProductItemComponent implements OnInit {
  openEditProduct: boolean = false;

  constructor(private dialog: MatDialog) { }

  ngOnInit(): void {
  }

  onEditProduct(){
    this.openEditProduct = true;
  }
  onClosed(){
    this.openEditProduct = false;
  }

  onDelete(){
    this.dialog.open(DeleteProductComponent)
  }
}
