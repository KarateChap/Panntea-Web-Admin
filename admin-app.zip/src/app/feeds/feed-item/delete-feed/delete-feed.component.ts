import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-feed',
  templateUrl: './delete-feed.component.html',
  styleUrls: ['./delete-feed.component.css']
})
export class DeleteFeedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
