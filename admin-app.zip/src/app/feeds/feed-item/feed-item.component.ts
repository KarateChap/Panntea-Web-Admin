import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DeleteFeedComponent } from './delete-feed/delete-feed.component';

@Component({
  selector: 'app-feed-item',
  templateUrl: './feed-item.component.html',
  styleUrls: ['./feed-item.component.css']
})
export class FeedItemComponent implements OnInit {

  openEditFeed = false;

  constructor(private dialog: MatDialog ) { }

  ngOnInit(): void {
  }

   onEditFeed(){
     this.openEditFeed = true;
   }
   onClosed(){
    this.openEditFeed = false;
   }

   onDelete(){
    this.dialog.open(DeleteFeedComponent)
   }
}
