import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feeds',
  templateUrl: './feeds.component.html',
  styleUrls: ['./feeds.component.css']
})
export class FeedsComponent implements OnInit {
  openAddFeed: boolean = false;

  constructor() { }

  ngOnInit(): void {
  }

  onOpenAddFeed(){
    this.openAddFeed = true;
  }
  onClosed(){
    this.openAddFeed = false;
  }
}
