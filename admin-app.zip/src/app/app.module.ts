import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainNavComponent } from './main-nav/main-nav.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatCardModule} from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule } from '@angular/material/dialog';
import { MatChipsModule } from '@angular/material/chips';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatTabsModule} from '@angular/material/tabs';

import { AnalyticsComponent } from './analytics/analytics.component';
import { CustomersComponent } from './customers/customers.component';
import { EmployeesComponent } from './employees/employees.component';
import { FeedsComponent } from './feeds/feeds.component';
import { MonitoringComponent } from './monitoring/monitoring.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { ProductsComponent } from './products/products.component';
import { AddProductComponent } from './products/add-product/add-product.component';
import { ProductItemComponent } from './products/product-item/product-item.component';
import { EditProductComponent } from './products/edit-product/edit-product.component';
import { DeleteProductComponent } from './products/product-item/delete-product/delete-product.component';
import { AddEmployeeComponent } from './employees/add-employee/add-employee.component';
import { EditEmployeeComponent } from './employees/edit-employee/edit-employee.component';
import { EmployeeItemComponent } from './employees/employee-item/employee-item.component';
import { DeleteEmployeeComponentComponent } from './employees/employee-item/delete-employee-component/delete-employee-component.component';
import { AddFeedComponent } from './feeds/add-feed/add-feed.component';
import { FeedItemComponent } from './feeds/feed-item/feed-item.component';
import { EditFeedComponent } from './feeds/edit-feed/edit-feed.component';
import { DeleteFeedComponent } from './feeds/feed-item/delete-feed/delete-feed.component';
import { CustomerItemComponent } from './customers/customer-item/customer-item.component';
import { LoginComponent } from './login/login.component';
import { WelcomePageComponent } from './welcome-page/welcome-page.component';
import { ParticlesModule } from 'angular-particle';
import { MonitoringItemComponent } from './monitoring/monitoring-item/monitoring-item.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PendingOrdersComponent } from './notifications/pending-orders/pending-orders.component';
import { PreparingComponent } from './notifications/preparing/preparing.component';
import { ForPickUpComponent } from './notifications/for-pick-up/for-pick-up.component';
import { OrderReceivedComponent } from './notifications/order-received/order-received.component';

@NgModule({
  declarations: [
    AppComponent,
    MainNavComponent,
    AnalyticsComponent,
    CustomersComponent,
    EmployeesComponent,
    FeedsComponent,
    MonitoringComponent,
    NotificationsComponent,
    ProductsComponent,
    AddProductComponent,
    ProductItemComponent,
    EditProductComponent,
    DeleteProductComponent,
    AddEmployeeComponent,
    EditEmployeeComponent,
    EmployeeItemComponent,
    DeleteEmployeeComponentComponent,
    AddFeedComponent,
    FeedItemComponent,
    EditFeedComponent,
    DeleteFeedComponent,
    CustomerItemComponent,
    LoginComponent,
    WelcomePageComponent,
    MonitoringItemComponent,
    PendingOrdersComponent,
    PreparingComponent,
    ForPickUpComponent,
    OrderReceivedComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,
    MatDialogModule,
    MatChipsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    ParticlesModule,
    MatProgressBarModule,
    MatTabsModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  entryComponents: [DeleteProductComponent, DeleteEmployeeComponentComponent, DeleteFeedComponent]
})
export class AppModule { }
