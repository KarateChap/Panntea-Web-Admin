import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-preparing',
  templateUrl: './preparing.component.html',
  styleUrls: ['./preparing.component.css']
})
export class PreparingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
