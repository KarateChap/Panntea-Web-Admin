import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-received',
  templateUrl: './order-received.component.html',
  styleUrls: ['./order-received.component.css']
})
export class OrderReceivedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
