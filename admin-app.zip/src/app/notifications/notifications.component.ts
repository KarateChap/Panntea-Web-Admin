import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css'],
})
export class NotificationsComponent implements OnInit {
  links = [
    { path: 'pending-orders', label: 'Pending-Orders' },
    { path: 'preparing', label: 'Preparing' },
    { path: 'for-pick-up', label: 'For-Pick-Up' },
    { path: 'order-received', label: 'Order-Received' },
  ];
  activeLink = this.links[0].label;

  constructor(private router: Router, private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.router.navigate(['pending-orders'], {relativeTo: this.route});
  }
}
