import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-for-pick-up',
  templateUrl: './for-pick-up.component.html',
  styleUrls: ['./for-pick-up.component.css']
})
export class ForPickUpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
